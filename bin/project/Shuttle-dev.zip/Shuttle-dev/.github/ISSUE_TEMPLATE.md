**Shuttle version:**
 
 v1.x.x
 
**Device, OS:**
 
Device info here

**Description of bug:**
 
Bug description here
 
**Steps to reproduce:**
 
 1. Step 1
 2. Step 2
 3. Step 3
 
**Expected outcome:**
 
Expected outcome here
 
**Observations/Actual Result:**
 
 Observations here